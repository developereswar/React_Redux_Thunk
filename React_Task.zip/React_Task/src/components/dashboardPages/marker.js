import React from 'react';


const Marker = props => {
    return (<div>
        <img src="https://assetsstatic.s3.ap-south-1.amazonaws.com/navigation.svg" width="24px"/>
            </div>) 
    
    }
export default Marker;